const runner = require('./generate')
runner()